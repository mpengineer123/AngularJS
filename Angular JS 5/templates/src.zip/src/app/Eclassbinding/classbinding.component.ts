import { Component } from '@angular/core';


@Component({
    selector:'app-classbinding',
    templateUrl: './classbinding.component.html',
    styleUrls:['./classbinding.component.css']
})



export class classbindingComponent{
    markingText:string = 'marking-text';
    equationText:string = "eqn-text";
    textItalic:string = 'text-italic';
    textBold:string = 'text-bold';
    textRed:string = 'text-red';
    textGreen:string = 'text-green';
    public hasError = false;
    public hasStyle = true;

    mutliClass = {
        'text-italic':this.hasStyle,
        'text-bold':this.hasStyle,
        'text-green':this.hasStyle,
        'text-red':this.hasError,
          

    }

}