import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
//    template: `This is Parent Compoment.<br>
//    Parent Data: <input type="text" #pData (keyup)="0"/><br>
//    <app-input [parentData]="pData.value"></app-input>
    
//    `
,

  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';
}
