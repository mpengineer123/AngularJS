import { Component } from "@angular/core";

@Component({
    selector: "app-basics",
    template: `
    <div>Class 01: Basics of Angular JS 5!!</div>
<hr>
    `,
    styles:[
        `div{
        background:yellow;
        padding:10px;
        color:red;
        font-weight:bold;
    }`],
})

export class basicsComponent{
    cssPath:string = "";
}