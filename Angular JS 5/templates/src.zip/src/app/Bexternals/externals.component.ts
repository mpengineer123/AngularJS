import { Component } from "@angular/core";


@Component({
    selector: '.app-externals',
    templateUrl: './externals.component.html',
    styleUrls: ['./externals.component.css'],

})






export class externalsComponent{
Bootstrap:string = "External Resource Apply";
externalImage:string = "https://blog.keycdn.com/blog/wp-content/uploads/2017/05/typescript-tutorial-730x365.webp"
localImage:string = './assets/taylor-swift-2014-sarah-barlow-billboard-650.jpg';
}