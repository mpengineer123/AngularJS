import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { basicsComponent } from './Abasics/basics.component';
import { externalsComponent } from './Bexternals/externals.component';
import { interpolationComponent } from './Cinterpolation/interpolation.component';
import { propertybindingComponent } from './Dpropertybinding/propertybinding.component';
import { classbindingComponent } from './Eclassbinding/classbinding.component';
import { stylebindingComponent } from './Fstylebinding/stylebinding.component';
import { eventbindingComponent } from './Geventbinding/eventbinding.component';
import { trvComponent } from './Htrv/trv.component';
import { twowaybindingComponent } from './Itwowaybinding/twowaybinding.component';
import { ngifComponent } from './Jngif/ngif.component';
import { ngswitchComponent } from './Kngswitch/ngswitch.component';
import { ngforComponent } from './Lngfor/ngfor.component';
import { inputComponent } from './Minput/input.component';
import { arrayComponent } from './Oarray/array.component';

@NgModule({
  declarations: [
    AppComponent,
    basicsComponent,
    externalsComponent,
    interpolationComponent,
    propertybindingComponent,
    classbindingComponent,
    stylebindingComponent,
    eventbindingComponent,
    trvComponent,
    twowaybindingComponent,
    ngifComponent,
    ngswitchComponent,
    ngforComponent,
    inputComponent,
    arrayComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
