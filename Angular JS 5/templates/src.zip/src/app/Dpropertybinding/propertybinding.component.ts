import { Component } from "@angular/core";


@Component({
    selector: 'app-propertybinding',
    templateUrl: './propertybinding.component.html',
    styleUrls: ['./propertybinding.component.css']
})




export class propertybindingComponent{

    message:string = 'Chapter 4: Property Binding';
    myId:string = "pg_01";
    addClass:string="well-sm bg-primary";
    public isDisable = true;
 
}