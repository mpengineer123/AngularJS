import { Component } from '@angular/core';

@Component({
    selector: '[app-interpolation]',
    templateUrl:'./interpolation.component.html',
    styleUrls:['./interpolation.component.css']
})

export class interpolationComponent{
Name:string = 'Manas Pradhan';
cssBoot:string = 'well-sm bg-primary dvBorder';
feature_1:string = "Normal data binding";
feature_2:string = "Expression";
feature_3:string = "DOM Property";
feature_4:string = "DOM Method";
feature_5:string = "Functions";
feature_6:string = "Ternary";
feature_7:string = "Concatenation";
feature_8:string = "Global Variable";
siteUrl:string = window.location.href;

a:number = 45.2;
b:number = 47;
Add(){
    return this.a+this.b;
}


}