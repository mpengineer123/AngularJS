import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-input',
    templateUrl: './input.component.html',
 //   template: `
 //   This is Child Component.<br>
 //   Parent Data Reveived: {{parentData}}<br>
 //   `
    styleUrls:['./input.component.css']

})



export class inputComponent{

    @Input() parentData:string;

}
