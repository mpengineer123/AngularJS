import { Component } from '@angular/core';

@Component({
    selector: 'app-trv',
    templateUrl: './trv.component.html',
    styleUrls: ['./trv.component.css']
})

export class trvComponent{

    
    info(userName,phoneNumber,password){
        console.log(userName);
        console.log(phoneNumber);
        console.log(password);
    }

}