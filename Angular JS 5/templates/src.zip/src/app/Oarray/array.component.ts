import { Component } from '@angular/core';

@Component({
    selector: 'app-array',
    templateUrl:'./array.component.html',
    styleUrls: ['./array.component.css']
})

export class arrayComponent{

products:any[] = [
{p_id:1,p_name:'Motorola',p_price:76000,p_image:'/assets/motorola.jpg'},
{p_id:2,p_name:'Oppo',p_price:20000,p_image:'/assets/oppo.png'},
{p_id:3,p_name:'Samsung',p_price:18000,p_image:'/assets/samsung.jpg'}
];

}