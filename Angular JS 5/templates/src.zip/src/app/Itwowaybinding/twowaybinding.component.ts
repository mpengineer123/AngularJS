import { Component } from '@angular/core';

@Component({
    selector:'app-twowaybinding',
    templateUrl: './twowaybinding.component.html',
    styleUrls: ['./twowaybinding.component.css']
})



export class twowaybindingComponent{
    
    public username = '';
    public password = '';
}