import { Component } from '@angular/core';

@Component({
    selector:'app-eventbinding',
    templateUrl: './eventbinding.component.html',
    styleUrls: ['./eventbinding.component.css']
})

export class eventbindingComponent{

    anotherMessage:string = ''; 
    anotherMessage2:string = ''; 
    messageShow(){
        console.log('Welcome to Angular JS 5!!');
        this.anotherMessage='Welcome to Angular JS 5!!';
    }

    eventTest(event){
        console.log(event);
        this.anotherMessage2 = event.type;
        
    }

}